#!/bin/bash

if ! command -v convert &>/dev/null; then
    echo "ImageMagick is not installed. Proceeding with installation..."
    
    sudo apt update
    
    sudo apt install imagemagick
    
    if ! command -v convert &>/dev/null; then
        echo "Failed to install ImageMagick. Please install it manually and try again."
        exit 1
    fi
    
    echo "ImageMagick has been installed successfully."
else
    echo "Found ImageMagick"
fi